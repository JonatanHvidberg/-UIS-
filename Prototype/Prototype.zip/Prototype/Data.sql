DELETE FROM Person;
DELETE FROM Relative;
DELETE FROM Patient;
DELETE FROM HealthProfessionals;
DELETE FROM PatientsRelatives;
DELETE FROM HealthProfessionals;
DELETE FROM Department;
DELETE FROM WorksIn;
DELETE FROM Reminders;
DELETE FROM Messages;
DELETE FROM Notes;
DELETE FROM Results;
DELETE FROM Questionnaire;
DELETE FROM QuestionnaireReply;

/*----------------------------------------------------------------------------------------------------*/
insert into Person values(2503902323,'uis','Emil Henriksen','Hjerteproblemer','34343434','Danmark');
insert into Person values(2405952323,'uis','Jonatan Hvidberg','UIS problemer','26125422','Danmark');

insert into Person values(2503902324,'uis','Emma Henriksen','Hjerteproblemer','24242424','Danmark');


insert into Person values(1311951114,'uis','Amalje Lærke','Noget er galt','11442233','Torstensgade 487');
insert into Person values(2506883113,'uis','Anders Kalseen','Notat','46534238','Torstensgade 48');
insert into Person values(3101502232,'uis','Ludvig Jortsen','Galt','11442233','Torstensgade 47');

/*----------------------------------------------------------------------------------------------------*/
insert into Relative values(2503902324);

/*----------------------------------------------------------------------------------------------------*/

insert into Patient values(2503902323);
insert into Patient values(2405952323);


/*----------------------------------------------------------------------------------------------------*/
insert into HealthProfessionals values(1311951114,'Læge');
insert into HealthProfessionals values(2506883113,'Hudlæge');
insert into HealthProfessionals values(3101502232,'Mavetarm Infektion');
/*----------------------------------------------------------------------------------------------------*/

insert into PatientsRelatives values(2503902323,2503902324);

/*----------------------------------------------------------------------------------------------------*/

insert into PatientsHealthProfessionals values(2503902323,1311951114);
insert into PatientsHealthProfessionals values(2503902323,2506883113);

/*----------------------------------------------------------------------------------------------------*/

insert into Department values('Lægevej 6','Hud');
insert into Department values('Sygevej 32','Hospital');
insert into Department values('FindVej 02','Øjne');

/*----------------------------------------------------------------------------------------------------*/

insert into WorksIn values('Lægevej 6',2506883113);
insert into WorksIn values('Sygevej 32',1311951114);
insert into WorksIn values('Sygevej 32',3101502232);

/*----------------------------------------------------------------------------------------------------*/

insert into Reminders values('Husk at vaske føderne','02/05/20:12.30','Lægevej 6','Fodvorter','2503902323','2506883113');
insert into Reminders values('Husk at have spist inden','02/05/20:13.30','Sygevej 32','Blodprøver','2503902323','1311951114');

/*----------------------------------------------------------------------------------------------------*/

insert into Messages values(2503902323,'Der er problemer med prøven, den skal tages igen','02/03/20:13.30','Blodprøvesvar',1,'1311951114');


/*----------------------------------------------------------------------------------------------------*/

insert into Notes values(2503902323,'Patienten er et bjeg, det virker som jernmangel',2,'1311951114');

/*----------------------------------------------------------------------------------------------------*/

insert into Results values(2503902323,1311951114,'25/01/2020',1);
insert into Results values(2503902323,1311951114,'26/01/2020',2);
insert into Results values(2503902323,1311951114,'27/01/2020',3);
insert into Results values(2503902323,1311951114,'28/01/2020',4);
insert into Results values(2503902323,1311951114,'29/01/2020',5);
insert into Results values(2503902323,1311951114,'30/01/2020',6);

insert into Results values(2405952323,1311951114,'30/01/2020',7);


/*----------------------------------------------------------------------------------------------------*/

insert into ResultsData values('mol/l','Blodsukker',734,1,1);
insert into ResultsData values('mol/l','Insulin Level',70,1,2);

insert into ResultsData values('mol/l','Blodsukker',723,2,3);
insert into ResultsData values('mol/l','Insulin Level',70,2,4);

insert into ResultsData values('mol/l','Blodsukker',745,3,5);

insert into ResultsData values('mol/l','Blodsukker',735,4,6);
insert into ResultsData values('mol/l','Insulin Level',70,4,7);

insert into ResultsData values('m/s^2','zxx',35,5,8);
insert into ResultsData values('v/c','kkx',70,5,9);
insert into ResultsData values('kg*m/s^2','Nuton',39,5,10);
insert into ResultsData values('E/c^2','Masse',89,5,11);
insert into ResultsData values('y/F','Dette er slet ikke en enhed',75,5,12);
insert into ResultsData values('ohm','Modstand',1,5,13);
insert into ResultsData values('s','ss',73,5,14);
insert into ResultsData values('p','pp',60,5,15);


insert into ResultsData values('mol/l','Blodsukker',798,6,16);
insert into ResultsData values('mol/l','Insulin Level',70,6,17);

insert into ResultsData values('mol/l','Blodsukker',1,7,18);
insert into ResultsData values('mol/l','Insulin Level',2,7,19);


/*----------------------------------------------------------------------------------------------------*/


insert into Questionnaire values('Ondt i ryggen, opkast, mangel på apetit',1);
insert into Questionnaire values('Smerter i hovedet, dårlig ånde',2);
insert into Questionnaire values('Træt,Sur,Glad',3);

/*----------------------------------------------------------------------------------------------------*/

insert into QuestionnaireReply values('5, Ja, Enig', 2, 2503902323);
insert into QuestionnaireReply values('3, 4, 2', 3, 2503902323);

/*----------------------------------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------*/
