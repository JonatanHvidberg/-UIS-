import random, os
from flask import render_template, url_for, flash, redirect, request, Blueprint, Response, send_from_directory
from minsp import app, conn, bcrypt
from minsp.forms import CustomerLoginForm, GraphForm
from flask_login import login_user, current_user, logout_user, login_required
from minsp.models import Customers, select_Customers, select_Health_Prof, select_test_res,select_Result_Types,select_specific_type_res
from minsp.hf import print_debug
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import datetime

Login = Blueprint('Login', __name__)

posts = [{}]


@Login.route("/")
@Login.route("/home")
def home():
    return render_template('home.html', posts=posts)


@Login.route("/about")
def about():
    return render_template('about.html', title='About')


@Login.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('Login.home'))
    form = CustomerLoginForm()
    if form.validate_on_submit():
        user = select_Customers(form.id.data)
        # need some salt for that
        if user != None: # and bcrypt.check_password_hash(user[1], form.password.data):
            login_user(user, remember=form.remember.data)
            flash('Login successful.','success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('Login.home'))
        else:
            flash('Login Unsuccessful. Please check identifier and password', 'danger')
    return render_template('login.html', title='Login', form=form)


@Login.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('Login.home'))


@Login.route("/account")
@login_required
def account():
    return render_template('account.html', title='Account')


@Login.route("/graph",methods=['GET', 'POST'])
@login_required
def graph():
    form = GraphForm()
    if form.validate_on_submit():
        # needs to get a date from to another date
        date_range = select_specific_type_res(current_user[0],'Blodsukker')
    fig = create_fig()
    filename = "/static/images/new_plot.png"
    fig.savefig("minsp" + filename, format='png')
    return render_template('graph.html', name='new_plot', url=filename, form=form)


def create_fig():
    fig = Figure()
    res = select_specific_type_res(current_user[0],'Blodsukker')
    dates = list()
    values = list()
    for r in res:
        dates.append(r[0])
        values.append(r[1])
    print_debug(res)
    axis = fig.add_subplot(1,1,1)
    axis.plot(dates, values)
    return fig



@Login.route("/health")
@login_required
def health():
    doctor = select_Health_Prof(current_user[0])  #should be cpr number
    return render_template("health.html", doctor=doctor, title="Contacts")


@Login.route("/results")
@login_required
def results():
    cpr = current_user[0]
    types = select_Result_Types(cpr)
    specific_types = select_specific_type_res(cpr, types[0])
    print_debug(types)

    res = select_test_res(cpr)
    return render_template("results.html", res=res, types=types, title="Test Results")
