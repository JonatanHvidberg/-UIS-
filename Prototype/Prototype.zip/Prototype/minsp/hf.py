#helper functions

def print_debug(str):
	print("\n\nDebug -->")
	print(str)
	print("<--Debug end\n\n")