#How to use the program

First create the database 'diabetes' for the user postgres

1. From the terminal
	- sudo psql -U postgres
2. Inside the psql terminal
	- CREATE DATABASE diabetes;
	- GRANT ALL PRIVILEGES ON DATABASE diabetes TO postgres;
3. Exiting the psql terminal, and running the following command from the  terminal
	- psql -d diabetes -U postgres -f minSP.sql
 	- psql -d diabetes -U postgres -f Data.sql