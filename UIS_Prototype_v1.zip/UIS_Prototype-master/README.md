See the Guide to install and run the Bank prototype on Absalon:
https://absalon.ku.dk/courses/31390/pages/guide-to-install-and-run-the-bank-prototype