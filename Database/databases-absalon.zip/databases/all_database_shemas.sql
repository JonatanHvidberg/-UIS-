﻿-- b_databaser
-- load sample databases
-- AL20161211

\i airline/airline-database/airline_schema_p.sql
\i airline/airline-database/insert_airline_p.sql

\i bar/bar-database/bar_schema_p.sql
\i bar/bar-database/insert_bar_p.sql

\i company/company-database/bank_p.sql
\i company/company-database/book_p.sql
\i company/company-database/employee_p.sql
\i company/company-database/room_schema_p.sql

\i movie/movie-database/movie_schema_p.sql

\i pc/pc-database/pc_schema_p.sql

\i ships/ships-database/ships_schema_p.sql

